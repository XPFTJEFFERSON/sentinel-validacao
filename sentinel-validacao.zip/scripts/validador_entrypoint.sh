#!/bin/bash
echo "🚀 Iniciando serviço de Validação de Dados Sentinel..."
sleep 1
bash validacao_main.sh
